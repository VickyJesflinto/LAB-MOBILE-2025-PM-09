package com.example.tp2_h071231092;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final int EDIT_PROFILE_REQUEST = 1;

    TextView textName, textPhone;
    ImageView btnEditProfile, profileImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Tambahan untuk ambil view dan pasang aksi
        textName = findViewById(R.id.textName);
        textPhone = findViewById(R.id.textPhone);
        btnEditProfile = findViewById(R.id.btnEditProfile);
        profileImage = findViewById(R.id.profileImage);

        btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
            intent.putExtra("name", textName.getText().toString());
            intent.putExtra("phone", textPhone.getText().toString());
            // Ambil URI gambar dari ImageView (kalau ada)
            if (profileImage.getTag() != null) {
                intent.putExtra("imageUri", profileImage.getTag().toString());
            }
            startActivityForResult(intent, EDIT_PROFILE_REQUEST);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == EDIT_PROFILE_REQUEST && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra("name");
            String phone = data.getStringExtra("phone");
            String imageUriString = data.getStringExtra("imageUri");

            textName.setText(name);
            textPhone.setText(phone);

            if (imageUriString != null) {
                Uri imageUri = Uri.parse(imageUriString);
                profileImage.setImageURI(imageUri);
                profileImage.setTag(imageUriString); // Simpan URI di tag
            }
        }
    }

}
