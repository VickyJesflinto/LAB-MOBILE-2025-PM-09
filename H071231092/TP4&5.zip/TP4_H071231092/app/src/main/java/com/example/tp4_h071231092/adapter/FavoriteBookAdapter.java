package com.example.tp4_h071231092.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.tp4_h071231092.DetailBookActivity;
import com.example.tp4_h071231092.Model.Book;
import com.example.tp4_h071231092.R;

import java.util.List;

public class FavoriteBookAdapter extends RecyclerView.Adapter<FavoriteBookAdapter.FavoriteBookViewHolder> {

    private final Context context;
    private List<Book> bookList;

    public FavoriteBookAdapter(Context context, List<Book> bookList) {
        this.context = context;
        this.bookList = bookList;
    }

    @NonNull
    @Override
    public FavoriteBookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_favorite_book, parent, false);
        return new FavoriteBookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteBookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.title.setText(book.getJudul());
        holder.author.setText(book.getPenulis());
        holder.blurb.setText(book.getBlurb());
        Glide.with(context).load(book.getGambar()).into(holder.image);

        // Set onClickListener to navigate to DetailBookActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailBookActivity.class);
            intent.putExtra("judul", book.getJudul());
            intent.putExtra("penulis", book.getPenulis());
            intent.putExtra("blurb", book.getBlurb());
            intent.putExtra("gambar", book.getGambar());
            intent.putExtra("thn_terbit", book.getThn_terbit());
            intent.putExtra("statusLike", book.getStatusLike());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public void updateData(List<Book> newBookList) {
        this.bookList = newBookList;
        notifyDataSetChanged();
    }

    public static class FavoriteBookViewHolder extends RecyclerView.ViewHolder {
        TextView title, author, blurb;
        ImageView image;

        public FavoriteBookViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvTitle);
            author = itemView.findViewById(R.id.tvAuthor);
            blurb = itemView.findViewById(R.id.tvBlurb);
            image = itemView.findViewById(R.id.ivBookImage);
        }
    }
}