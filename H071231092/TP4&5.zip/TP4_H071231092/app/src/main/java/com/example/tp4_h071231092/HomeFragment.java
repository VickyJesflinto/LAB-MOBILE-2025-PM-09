package com.example.tp4_h071231092;

import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.tp4_h071231092.Data.BookData;
import com.example.tp4_h071231092.Model.Book;
import com.example.tp4_h071231092.adapter.BookAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class HomeFragment extends Fragment {

    private BookAdapter adapter;
    private List<Book> bookList;
    private ProgressBar progressBar;
    private ExecutorService executorService;
    private Handler mainHandler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        RecyclerView rv_books = view.findViewById(R.id.rvBooks);
        rv_books.setLayoutManager(new GridLayoutManager(getContext(), 2));

        progressBar = view.findViewById(R.id.progressBar);
        executorService = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());

        BookData.initializeDummyData(requireContext().getPackageName());
        bookList = BookData.getBookList();

        // Set adapter (assign to the class-level adapter field)
        adapter = new BookAdapter(getContext(), bookList);
        rv_books.setAdapter(adapter);

        // Setup SearchView
        SearchView searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                performSearch(newText);
                return true;
            }
        });

        return view;
    }

    private void performSearch(String query) {
        progressBar.setVisibility(View.VISIBLE);
        adapter.updateData(new ArrayList<>());
        executorService.execute(() -> {
            List<Book> filteredList = new ArrayList<>();
            for (Book book : bookList) {
                if (!TextUtils.isEmpty(book.getJudul()) && book.getJudul().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(book);
                }
            }
            mainHandler.postDelayed(() -> {
                adapter.updateData(filteredList);
                progressBar.setVisibility(View.GONE);
            }, 1000);
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}