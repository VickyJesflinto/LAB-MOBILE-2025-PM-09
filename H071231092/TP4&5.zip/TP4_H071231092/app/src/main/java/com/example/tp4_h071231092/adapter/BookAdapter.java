package com.example.tp4_h071231092.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.tp4_h071231092.DetailBookActivity;
import com.example.tp4_h071231092.Model.Book;
import com.example.tp4_h071231092.R;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private final Context context;
    private List<Book> bookList;

    public BookAdapter(Context context, List<Book> bookList) {
        this.context = context;
        this.bookList = bookList;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.title.setText(book.getJudul());
        holder.author.setText(book.getPenulis());
        Glide.with(context).load(book.getGambar()).into(holder.image);

        // Set click listener to open DetailBookActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailBookActivity.class);
            intent.putExtra("judul", book.getJudul());
            intent.putExtra("penulis", book.getPenulis());
            intent.putExtra("thn_terbit", book.getThn_terbit());
            intent.putExtra("blurb", book.getBlurb());
            intent.putExtra("gambar", book.getGambar());
            intent.putExtra("statusLike", book.getStatusLike());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    // Add the updateData method
    public void updateData(List<Book> newBookList) {
        this.bookList = newBookList; // Update the book list
        notifyDataSetChanged(); // Notify the adapter to refresh the RecyclerView
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView title, author;
        ImageView image;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvTitle);
            author = itemView.findViewById(R.id.tvAuthor);
            image = itemView.findViewById(R.id.ivBookImage);
        }
    }


}
