package com.example.tp4_h071231092;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.tp4_h071231092.Data.BookData;
import com.example.tp4_h071231092.Model.Book;
import com.example.tp4_h071231092.adapter.BookAdapter;
import com.example.tp4_h071231092.adapter.FavoriteBookAdapter;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FavoriteFragment extends Fragment {

    private FavoriteBookAdapter adapter;
    private ProgressBar progressBar;
    private ExecutorService executorService;
    private Handler mainHandler;
    private RecyclerView rvFavorites;
    private TextView tvEmpty;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);

        rvFavorites = view.findViewById(R.id.rvFavorites);
        rvFavorites.setLayoutManager(new LinearLayoutManager(getContext())); // Linear layout

        progressBar = view.findViewById(R.id.progressBarFavorites);
        tvEmpty = view.findViewById(R.id.tvEmpty);
        executorService = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());

        loadFavorites();

        return view;
    }

    private void loadFavorites() {
        progressBar.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);
        rvFavorites.setVisibility(View.GONE);
        executorService.execute(() -> {
            List<Book> likedBooks = BookData.getLikedBooks();
            mainHandler.postDelayed(() -> {
                if (likedBooks.isEmpty()) {
                    tvEmpty.setVisibility(View.VISIBLE);
                } else {
                    tvEmpty.setVisibility(View.GONE);
                    rvFavorites.setVisibility(View.VISIBLE);
                    adapter = new FavoriteBookAdapter(getContext(), likedBooks);
                    rvFavorites.setAdapter(adapter);
                }
                progressBar.setVisibility(View.GONE);
            }, 1000);
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadFavorites();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }

}
