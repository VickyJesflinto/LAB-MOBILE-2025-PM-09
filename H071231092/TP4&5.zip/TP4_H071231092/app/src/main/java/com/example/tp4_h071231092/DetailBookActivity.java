package com.example.tp4_h071231092;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.tp4_h071231092.Data.BookData;
import com.example.tp4_h071231092.Model.Book;

public class DetailBookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail_book);

        String judul = getIntent().getStringExtra("judul");
        String penulis = getIntent().getStringExtra("penulis");
        String thnTerbit = getIntent().getStringExtra("thn_terbit");
        String blurb = getIntent().getStringExtra("blurb");
        String gambar = getIntent().getStringExtra("gambar");
        final String[] statusLike = {getIntent().getStringExtra("statusLike")};

        TextView tvJudul = findViewById(R.id.tvJudul);
        TextView tvPenulis = findViewById(R.id.tvPenulis);
        TextView tvThnTerbit = findViewById(R.id.tvThnTerbit);
        TextView tvBlurb = findViewById(R.id.tvBlurb);
        ImageView ivGambar = findViewById(R.id.ivGambar);
        ImageButton btnLike = findViewById(R.id.btnLike);

        tvJudul.setText(judul);
        tvPenulis.setText(penulis);
        tvThnTerbit.setText(thnTerbit);
        tvBlurb.setText(blurb);
        Glide.with(this).load(gambar).into(ivGambar);


        btnLike.setImageResource(statusLike[0].equals("liked") ? R.drawable.star_solid_24_yellow : R.drawable.star_solid_24);

        btnLike.setOnClickListener(v -> {
            if (statusLike[0].equals("liked")) {
                statusLike[0] = "unliked";
                btnLike.setImageResource(R.drawable.star_solid_24);
                updateBookStatus(judul, "unliked");
            } else {
                statusLike[0] = "liked";
                btnLike.setImageResource(R.drawable.star_solid_24_yellow);
                updateBookStatus(judul, "liked");
                Toast.makeText(DetailBookActivity.this, "Added to Favorites", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateBookStatus(String judul, String newStatus) {
        Book targetBook = null;
        for (Book book : BookData.getBookList()) {
            if (book.getJudul().equals(judul)) {
                book.setStatusLike(newStatus);
                targetBook = book;
                break;
            }
        }


        if (targetBook != null && "liked".equals(newStatus)) {
            BookData.getBookList().remove(targetBook);
            BookData.getBookList().add(0, targetBook); // Add to the top of the list
        }
    }

}