package com.example.tp4_h071231092.Model;

public class Book {

    // Attributes
    private String judul;
    private String penulis;
    private String thn_terbit;
    private String blurb;
    private String gambar;
    private String statusLike;

    // Constructor
    public Book(String judul, String penulis, String thn_terbit, String blurb, String gambar, String statusLike) {
        this.judul = judul;
        this.penulis = penulis;
        this.thn_terbit = thn_terbit;
        this.blurb = blurb;
        this.gambar = gambar;
        this.statusLike = statusLike;
    }

    // Getters and Setters Judul
    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    // Getters and Setters Penulis
    public String getPenulis() {
        return penulis;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    // Getters and Setters Tahun Terbit
    public String getThn_terbit() {
        return thn_terbit;
    }

    public void setThn_terbit(String thn_terbit) {
        this.thn_terbit = thn_terbit;
    }

    // Getters and Setters Blurb
    public String getBlurb() {
        return blurb;
    }

    public void setBlurb(String blurb) {
        this.blurb = blurb;
    }

    // Getters and Setters Gambar
    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    // Getters and Setters Status
    public String getStatusLike() {
        return statusLike;
    }

    public void setStatusLike(String statusLike) {
        this.statusLike = statusLike;
    }
}
