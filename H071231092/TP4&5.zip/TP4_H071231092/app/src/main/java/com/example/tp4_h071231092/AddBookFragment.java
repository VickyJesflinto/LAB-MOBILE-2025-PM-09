package com.example.tp4_h071231092;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.tp4_h071231092.Data.BookData;
import com.example.tp4_h071231092.Model.Book;

import java.io.IOException;

public class AddBookFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText etTitle, etAuthor, etYear, etBlurb;
    private ImageView ivCover;
    private Uri selectedImageUri;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_book, container, false);

        etTitle = view.findViewById(R.id.etTitle);
        etAuthor = view.findViewById(R.id.etAuthor);
        etYear = view.findViewById(R.id.etYear);
        etBlurb = view.findViewById(R.id.etBlurb);
        ivCover = view.findViewById(R.id.ivCover);
        Button btnSelectImage = view.findViewById(R.id.btnSelectImage);
        Button btnAddBook = view.findViewById(R.id.btnAddBook);

        btnSelectImage.setOnClickListener(v -> openGallery());
        btnAddBook.setOnClickListener(v -> addBook());

        return view;
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImageUri);
                ivCover.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addBook() {
        String title = etTitle.getText().toString().trim();
        String author = etAuthor.getText().toString().trim();
        String year = etYear.getText().toString().trim();
        String blurb = etBlurb.getText().toString().trim();

        if (title.isEmpty() || author.isEmpty() || year.isEmpty() || blurb.isEmpty() || selectedImageUri == null) {
            Toast.makeText(getContext(), "Please fill all fields and select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        Book newBook = new Book(
                title,
                author,
                year,
                blurb,
                selectedImageUri.toString(),
                "unliked"
        );

        BookData.addBook(newBook);
        Toast.makeText(getContext(), "Book added successfully", Toast.LENGTH_SHORT).show();

        // Clear the form
        etTitle.setText("");
        etAuthor.setText("");
        etYear.setText("");
        etBlurb.setText("");
        ivCover.setImageResource(0);
        selectedImageUri = null;
    }
}