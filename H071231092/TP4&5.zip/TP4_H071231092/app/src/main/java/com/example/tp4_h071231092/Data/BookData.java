package com.example.tp4_h071231092.Data;

import com.example.tp4_h071231092.Model.Book;

import java.util.ArrayList;
import java.util.List;

public class BookData {

    private static final List<Book> bookList = new ArrayList<>();

    // Method untuk ambil semua buku
    public static List<Book> getBookList() {
        return new ArrayList<>(bookList); // Return a copy of the list
    }

    public static List<Book> getLikedBooks() {
        List<Book> likedBooks = new ArrayList<>();
        for (Book book : bookList) {
            if ("liked".equals(book.getStatusLike())) {
                likedBooks.add(book);
            }
        }
        return likedBooks; // Return a new list
    }

    // Method untuk menambah buku
    public static void addBook(Book book) {
        bookList.add(0, book); // Masukkan di index 0 supaya buku baru muncul di atas
    }

    // Method untuk inisialisasi dummy data (hanya sekali)
    public static void initializeDummyData(String packageName) {
        if (bookList.isEmpty()) {
            bookList.add(new Book(
                    "Can't Hurt Me",
                    "David Goggins",
                    "2020",
                    "Dalam buku ini, David Goggins mengisahkan perjalanan hidupnya dari masa kecil " +
                            "penuh kekerasan hingga menjadi Navy SEAL dan atlet ultra. Ia membongkar rahasia " +
                            "mentalitas tangguh dan menunjukkan bahwa batas sejati ada di pikiran kita. Sebuah " +
                            "kisah inspiratif tentang kekuatan tekad dan ketahanan diri.",
                    "android.resource://" + packageName + "/drawable/can_t_hurt_me",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Atomic Habits",
                    "James Clear",
                    "2018",
                    "Perubahan besar dimulai dari kebiasaan kecil. Dalam Atomic Habits, James Clear " +
                            "membagikan strategi sederhana namun ampuh untuk membentuk kebiasaan baik, " +
                            "menghentikan yang buruk, dan menciptakan sistem perubahan berkelanjutan. " +
                            "Panduan praktis ini membantu kamu menjadi 1% lebih baik setiap hari.",
                    "android.resource://" + packageName + "/drawable/atomic_habits",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Knife Drop: Creative Recipes Anyone Can Cook",
                    "Nick DiGiovanni",
                    "2023",
                    "Lewat Knife Drop, chef sekaligus kreator Nick DiGiovanni menghadirkan kumpulan " +
                            "resep kreatif yang seru, mudah, dan bisa dibuat siapa saja. Dengan gaya santai " +
                            "dan penuh warna, buku ini mengajak kamu bereksperimen di dapur tanpa takut " +
                            "gagal—karena memasak seharusnya menyenangkan!",
                    "android.resource://" + packageName + "/drawable/knife_drop",
                    "unliked"
            ));
            bookList.add(new Book(
                    "The Subtle Art of Not Giving a F*ck",
                    "Mark Manson",
                    "2016",
                    "Buku ini membahas cara hidup lebih baik dengan menerima keterbatasan dan memilih " +
                            "apa yang benar-benar penting untuk diperjuangkan.",
                    "android.resource://" + packageName + "/drawable/the_subtle_art",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Rich Dad Poor Dad",
                    "Robert T. Kiyosaki",
                    "1997",
                    "Pelajaran keuangan dari dua sosok ayah yang berbeda, mengajarkan pentingnya " +
                            "literasi finansial dan investasi sejak dini.",
                    "android.resource://" + packageName + "/drawable/rich_dad_poor_dad",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Ikigai: The Japanese Secret to a Long and Happy Life",
                    "Héctor García & Francesc Miralles",
                    "2016",
                    "Mengungkap filosofi Jepang tentang menemukan tujuan hidup yang membuat hidup " +
                            "lebih bermakna dan panjang umur.",
                    "android.resource://" + packageName + "/drawable/ikigai",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Deep Work",
                    "Cal Newport",
                    "2016",
                    "Panduan meningkatkan fokus dan produktivitas dalam dunia yang penuh distraksi " +
                            "digital.",
                    "android.resource://" + packageName + "/drawable/deep_work",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Sapiens: A Brief History of Humankind",
                    "Yuval Noah Harari",
                    "2011",
                    "Sebuah perjalanan sejarah umat manusia, dari zaman purba hingga era modern, " +
                            "dengan sudut pandang kritis dan menyegarkan.",
                    "android.resource://" + packageName + "/drawable/sapiens",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Think and Grow Rich",
                    "Napoleon Hill",
                    "1937",
                    "Klasik pengembangan diri yang membahas kekuatan pikiran dan prinsip kesuksesan " +
                            "dari tokoh-tokoh besar dunia.",
                    "android.resource://" + packageName + "/drawable/think_and_grow_rich",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Educated",
                    "Tara Westover",
                    "2018",
                    "Memoar tentang perjuangan seorang wanita untuk memperoleh pendidikan meski " +
                            "dibesarkan dalam keluarga ekstremis dan tanpa sekolah formal.",
                    "android.resource://" + packageName + "/drawable/educated",
                    "unliked"
            ));

            bookList.add(new Book(
                    "The Power of Now",
                    "Eckhart Tolle",
                    "1997",
                    "Buku spiritual yang mengajarkan kekuatan kesadaran penuh pada saat ini " +
                            "sebagai kunci kebahagiaan dan kedamaian batin.",
                    "android.resource://" + packageName + "/drawable/the_power_of_now",
                    "unliked"
            ));

            bookList.add(new Book(
                    "Start With Why",
                    "Simon Sinek",
                    "2009",
                    "Menjelaskan pentingnya memulai segala hal dari 'mengapa' untuk membangun " +
                            "kepemimpinan dan organisasi yang menginspirasi.",
                    "android.resource://" + packageName + "/drawable/start_with_why",
                    "unliked"
            ));

            bookList.add(new Book(
                    "The Psychology of Money",
                    "Morgan Housel",
                    "2020",
                    "Mengungkap cara orang berpikir tentang uang dan keputusan keuangan dalam " +
                            "kehidupan nyata, bukan hanya teori.",
                    "android.resource://" + packageName + "/drawable/psychology_of_money",
                    "unliked"
            ));

            bookList.add(new Book(
                    "The Alchemist",
                    "Paulo Coelho",
                    "1988",
                    "Kisah fabel magis tentang seorang gembala yang mencari harta karun dan menemukan " +
                            "makna hidupnya di sepanjang perjalanan.",
                    "android.resource://" + packageName + "/drawable/the_alchemist",
                    "unliked"
            ));

            bookList.add(new Book(
                    "How to Win Friends and Influence People",
                    "Dale Carnegie",
                    "1936",
                    "Panduan klasik membangun relasi, berkomunikasi efektif, dan memengaruhi orang " +
                            "lain secara positif.",
                    "android.resource://" + packageName + "/drawable/how_to_win_friends",
                    "unliked"
            ));

        }
    }
}