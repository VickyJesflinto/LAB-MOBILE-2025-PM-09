package com.example.tp3_h071231092new.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp3_h071231092new.DetailFeedActivity;
import com.example.tp3_h071231092new.R;
import com.example.tp3_h071231092new.model.Feed;

import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder> {

    private final Context context;
    private final List<Feed> feedList;

    public FeedAdapter(Context context, List<Feed> feedList) {
        this.context = context;
        this.feedList = feedList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_feed, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Feed feed = feedList.get(position);
        Uri imageUri = Uri.parse(feed.getImageUri());
        holder.imageView.setImageURI(imageUri);

        // Set click listener to open DetailFeedActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailFeedActivity.class);
            intent.putExtra("imgUri", feed.getImageUri());
            intent.putExtra("caption", feed.getCaption());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return feedList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_feed);
        }
    }
}