package com.example.tp3_h071231092new.model;

public class Feed {
    private String imageUri;
    private String caption;

    // Constructor
    public Feed(String imageUri, String caption) {
        this.imageUri = imageUri;
        this.caption = caption;
    }

    // Getter untuk URI gambar
    public String getImageUri() {
        return imageUri;
    }

    // Setter untuk URI gambar
    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    // Getter untuk caption
    public String getCaption() {
        return caption;
    }

    // Setter untuk caption
    public void setCaption(String caption) {
        this.caption = caption;
    }
}