package com.example.tp3_h071231092new.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.tp3_h071231092new.ProfileActivity;
import com.example.tp3_h071231092new.R;
import com.example.tp3_h071231092new.model.Post;
import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {
    private List<Post> posts;
    private Context context;

    public PostAdapter(Context context, List<Post> posts) {
        this.context = context;
        this.posts = posts;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        Post post = posts.get(position);
        holder.ivProfile.setImageResource(post.getProfileRes());
        holder.tvUsername.setText(post.getUsername());
        holder.ivPost.setImageResource(post.getPostRes());
        holder.CapUsername.setText(post.getUsername());
        holder.textCaption.setText("Ini postingan " + post.getUsername());

        View.OnClickListener listener = v -> {
            Intent intent = new Intent(context, ProfileActivity.class);
            intent.putExtra("username", post.getUsername());
            intent.putExtra("profileImageResId", post.getProfileRes());
            intent.putExtra("jumlahPostingan", post.getJumlahPostingan());
            intent.putExtra("jumlahPengikut", post.getJumlahPengikut());
            intent.putExtra("jumlahMengikuti", post.getJumlahMengikuti());
            intent.putExtra("postResId", post.getPostRes());
            context.startActivity(intent);
        };

        holder.ivProfile.setOnClickListener(listener);
        holder.tvUsername.setOnClickListener(listener);
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    static class PostViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProfile;
        TextView tvUsername, CapUsername, textCaption;
        ImageView ivPost;

        PostViewHolder(View itemView) {
            super(itemView);
            ivProfile = itemView.findViewById(R.id.ivProfile);
            tvUsername = itemView.findViewById(R.id.tvUsername);
            ivPost = itemView.findViewById(R.id.ivPost);
            CapUsername = itemView.findViewById(R.id.CapUsername);
            textCaption = itemView.findViewById(R.id.text_caption);
        }
    }
}
