package com.example.tp3_h071231092new;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class DetailStoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail_story);

        ImageView imgStory = findViewById(R.id.img_detail_story);
        TextView tvUsername = findViewById(R.id.tv_username_story);

        int storyRes = getIntent().getIntExtra("storyImage", R.drawable.ic_launcher_foreground);
        imgStory.setImageResource(storyRes);

        // Dummy username untuk sekarang
        tvUsername.setText("Natho (￣ヘ￣メ)");

    }
}
