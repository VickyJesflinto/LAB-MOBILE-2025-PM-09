package com.example.tp3_h071231092new;

import static com.example.tp3_h071231092new.data.FeedData.addPost;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp3_h071231092new.adapter.FeedAdapter;
import com.example.tp3_h071231092new.adapter.StoryAdapter;
import com.example.tp3_h071231092new.data.FeedData;
import com.example.tp3_h071231092new.model.Feed;

import java.util.Arrays;
import java.util.List;

public class UserProfileActivity extends AppCompatActivity {

    private FeedAdapter feedAdapter;
    private RecyclerView rvFeed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_profile);

        // Inisialisasi RecyclerView untuk Feed
        rvFeed = findViewById(R.id.rv_feed);
        rvFeed.setLayoutManager(new GridLayoutManager(this, 3));

        // Pastikan data dummy hanya diinisialisasi jika feedList kosong
        if (FeedData.getFeedList().isEmpty()) {
            FeedData.initializeDummyData(getPackageName());
        }

        feedAdapter = new FeedAdapter(this, FeedData.getFeedList());
        rvFeed.setAdapter(feedAdapter);

        // Inisialisasi RecyclerView untuk Story
        RecyclerView rvStory = findViewById(R.id.rv_story);
        List<Integer> dummyStories = Arrays.asList(
                R.drawable.alpha,
                R.drawable.angelapost1,
                R.drawable.argus,
                R.drawable.wanwanpost1,
                R.drawable.lingpost1,
                R.drawable.nanapost1,
                R.drawable.moskovpost1
        );
        StoryAdapter storyAdapter = new StoryAdapter(this, dummyStories);
        rvStory.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvStory.setAdapter(storyAdapter);

        // Terima Intent untuk post baru
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("imageUri")) {
            String caption = intent.getStringExtra("caption");
            String imageUriString = intent.getStringExtra("imageUri");

            if (imageUriString != null) {
                Uri imageUri = Uri.parse(imageUriString);
                Feed newFeed = new Feed(imageUri.toString(),caption);
                addPost(newFeed); // Tambahkan feed baru
            }
        }

        // Tombol navigasi
        ImageButton btnHome = findViewById(R.id.btnHome);
        ImageButton btnAdd = findViewById(R.id.btnAdd);
        ImageButton btnProfile = findViewById(R.id.btnProfile);

        btnHome.setOnClickListener(v -> {
            Intent intent1 = new Intent(UserProfileActivity.this, MainActivity.class);
            startActivity(intent1);
        });

        btnAdd.setOnClickListener(v -> {
            Intent intent1 = new Intent(UserProfileActivity.this, AddActivity.class);
            startActivity(intent1);
        });

        btnProfile.setOnClickListener(v -> {
            recreate();
        });
    }
}