package com.example.tp3_h071231092new.data;

import com.example.tp3_h071231092new.R;
import com.example.tp3_h071231092new.model.Feed;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FeedData {
    private static final List<Feed> feedList = new ArrayList<>();

    // Method untuk ambil semua feed
    public static List<Feed> getFeedList() {
        return feedList;
    }

    public static void addPost(Feed feed) {
        feedList.add(0, feed); // Masukkan di index 0 supaya postingan baru muncul di atas
    }

    // Method untuk inisialisasi dummy data (hanya sekali)
    public static void initializeDummyData(String packageName) {
        if (feedList.isEmpty()) {
            feedList.addAll(Arrays.asList(
                    new Feed("android.resource://" + packageName + "/" + R.drawable.post1, "Ini caption postingan ke-1"),
                    new Feed("android.resource://" + packageName + "/" + R.drawable.lingpost1, "Ini caption postingan ke-2"),
                    new Feed("android.resource://" + packageName + "/" + R.drawable.fannypost1, "Ini caption postingan ke-3"),
                    new Feed("android.resource://" + packageName + "/" + R.drawable.choupost1, "Ini caption postingan ke-4"),
                    new Feed("android.resource://" + packageName + "/" + R.drawable.angelapost1, "Ini caption postingan ke-5")
            ));
        }
    }
}
