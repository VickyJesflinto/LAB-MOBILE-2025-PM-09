package com.example.tp3_h071231092new;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    ImageView imageProfile, imagePost;
    TextView textUsernameProfile, textUsernameToolbar, textUsernameBio, postinganTV, pengikutTV, mengikutiTV;
    ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        //Profile
        imageProfile = findViewById(R.id.image_profile_profile);
        textUsernameProfile = findViewById(R.id.text_username_profile);
        textUsernameToolbar = findViewById(R.id.text_username_toolbar);
        imagePost = findViewById(R.id.ig_Post_1);
        textUsernameBio = findViewById(R.id.text_username_bio);
        postinganTV = findViewById(R.id.tl_postingan);
        pengikutTV = findViewById(R.id.tl_pengikut);
        mengikutiTV = findViewById(R.id.tl_mengikuti);
        backButton = findViewById(R.id.Back_btn);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        int profileImage = intent.getIntExtra("profileImageResId", R.drawable.ic_launcher_foreground);
        int postImage = intent.getIntExtra("postResId", R.drawable.ic_launcher_foreground);
        int postingan = intent.getIntExtra("jumlahPostingan", 0);
        int pengikut = intent.getIntExtra("jumlahPengikut", 0);
        int mengikuti = intent.getIntExtra("jumlahMengikuti", 0);

        textUsernameToolbar.setText(username);
        textUsernameProfile.setText(username);
        textUsernameBio.setText("Halo ini bionya " + username);
        imageProfile.setImageResource(profileImage);
        imagePost.setImageResource(postImage);
        postinganTV.setText(String.valueOf(postingan));
        pengikutTV.setText(String.valueOf(pengikut));
        mengikutiTV.setText(String.valueOf(mengikuti));

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
