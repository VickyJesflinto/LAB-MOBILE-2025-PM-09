package com.example.tp3_h071231092new.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp3_h071231092new.R;

import java.util.List;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder> {
    private Context context;
    private List<Integer> storyImages;

    public StoryAdapter(Context context, List<Integer> storyImages) {
        this.context = context;
        this.storyImages = storyImages;
    }

    @NonNull
    @Override
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_story, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryAdapter.ViewHolder holder, int position) {
        holder.imgStory.setImageResource(storyImages.get(position));

        holder.imgStory.setOnClickListener(v -> {
            Intent intent = new Intent(context, com.example.tp3_h071231092new.DetailStoryActivity.class);
            intent.putExtra("storyImage", storyImages.get(position));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return storyImages.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgStory;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgStory = itemView.findViewById(R.id.img_story);
        }

    }


}
