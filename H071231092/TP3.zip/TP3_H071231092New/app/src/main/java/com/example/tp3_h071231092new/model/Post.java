package com.example.tp3_h071231092new.model;

import android.net.Uri;

import androidx.annotation.DrawableRes;

public class Post {
    private String username;
    @DrawableRes
    private int profileRes;
    @DrawableRes
    private int postRes;
    private int jumlahPostingan;
    private int jumlahPengikut;
    private int jumlahMengikuti;

    public Post(String username, int profileRes, int postRes, int jumlahPostingan, int jumlahPengikut, int jumlahMengikuti) {
        this.username = username;
        this.profileRes = profileRes;
        this.postRes = postRes;
        this.jumlahPostingan = jumlahPostingan;
        this.jumlahPengikut = jumlahPengikut;
        this.jumlahMengikuti = jumlahMengikuti;
    }

    public String getUsername() {
        return username;
    }

    public int getProfileRes() {
        return profileRes;
    }

    public int getPostRes() {
        return postRes;
    }

    public int getJumlahPostingan() {
        return jumlahPostingan;
    }

    public int getJumlahPengikut() {
        return jumlahPengikut;
    }

    public int getJumlahMengikuti() {
        return jumlahMengikuti;
    }
}
