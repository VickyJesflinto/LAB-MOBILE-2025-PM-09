package com.example.tp3_h071231092new;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class DetailFeedActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail_feed);

        ImageView img = findViewById(R.id.img_detail_feed);
        TextView captionText = findViewById(R.id.tv_caption);

        // Retrieve data from Intent
        String imageUriString = getIntent().getStringExtra("imgUri");
        String caption = getIntent().getStringExtra("caption");

        if (imageUriString != null) {
            Uri imageUri = Uri.parse(imageUriString);
            img.setImageURI(imageUri);
        } else {
            img.setImageResource(R.drawable.ic_launcher_foreground);
        }

        if (caption != null) {
            captionText.setText(caption);
        } else {
            captionText.setText("No caption available");
        }
    }
}