package com.example.tp3_h071231092new;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tp3_h071231092new.adapter.PostAdapter;
import com.example.tp3_h071231092new.model.Post;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ImageButton btnHome, btnAdd, btnProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        RecyclerView rvPosts = findViewById(R.id.rvPosts);
        rvPosts.setLayoutManager(new LinearLayoutManager(this));

        List<Post> dummyPosts = new ArrayList<>();
        dummyPosts.add(new Post("Layla", R.drawable.layla, R.drawable.post1, 10, 150, 120));
        dummyPosts.add(new Post("Angela", R.drawable.angela, R.drawable.angelapost1, 25, 300, 200));
        dummyPosts.add(new Post("Fanny", R.drawable.fanny, R.drawable.fannypost1, 12, 250, 150));
        dummyPosts.add(new Post("Ling", R.drawable.ling, R.drawable.lingpost1,1, 400, 100));
        dummyPosts.add(new Post("Chou", R.drawable.chou, R.drawable.choupost1, 41, 132, 300));
        dummyPosts.add(new Post("Moskov", R.drawable.moskov, R.drawable.moskovpost1, 5, 323, 122));
        dummyPosts.add(new Post("Nana", R.drawable.nana, R.drawable.nanapost1, 8, 384, 103));
        dummyPosts.add(new Post("Wanwan", R.drawable.wanwan, R.drawable.wanwanpost1, 16, 290, 123));
        dummyPosts.add(new Post("Chopper", R.drawable.sheep, R.drawable.sheeppost1, 7, 100, 210));
        dummyPosts.add(new Post("Alex", R.drawable.sheep2, R.drawable.sheep2post1, 3, 80, 12));

        PostAdapter adapter = new PostAdapter(this, dummyPosts);
        rvPosts.setAdapter(adapter);


        //Button
        btnHome = findViewById(R.id.btnHome);
        btnAdd = findViewById(R.id.btnAdd);
        btnProfile = findViewById(R.id.btnProfile);

        // Fungsi tombol Home
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvPosts.smoothScrollToPosition(0);
            }
        });

        // Fungsi tombol Add
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke AddActivity untuk menambah postingan
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        // Fungsi tombol Profile
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UserProfileActivity.class);
                startActivity(intent);
            }
        });
    }
}