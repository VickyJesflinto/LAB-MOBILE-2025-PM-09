package com.example.tp6_h071231092;

public class Character {
    private int id;
    private String name;
    private String status;
    private String species;
    private String image;
    private String gender;

    public int getId() { return id; }
    public String getName() { return name; }
    public String getStatus() { return status; }
    public String getSpecies() { return species; }
    public String getImage() { return image; }
    public String getGender() { return gender; }
}

