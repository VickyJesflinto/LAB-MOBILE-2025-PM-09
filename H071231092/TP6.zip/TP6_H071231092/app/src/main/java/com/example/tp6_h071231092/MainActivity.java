package com.example.tp6_h071231092;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    CharacterAdapter adapter;
    int currentPage = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        LinearLayout errorLayout = findViewById(R.id.errorLayout);
        ImageButton btnRetry = findViewById(R.id.btnRetry);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CharacterAdapter();
        recyclerView.setAdapter(adapter);

        adapter.setOnLoadMoreListener(() -> {
            loadCharacters(++currentPage, null);
        });

        if (NetworkUtil.isNetworkAvailable(this)) {
            progressBar.setVisibility(View.VISIBLE);
            errorLayout.setVisibility(View.GONE);
            loadCharacters(currentPage, progressBar);
        } else {
            progressBar.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
        }

        btnRetry.setOnClickListener(v -> {
            if (NetworkUtil.isNetworkAvailable(this)) {
                progressBar.setVisibility(View.VISIBLE);
                errorLayout.setVisibility(View.GONE);
                loadCharacters(currentPage, progressBar);
            } else {
                Toast.makeText(this, "Tidak ada koneksi internet", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void loadCharacters(int page, ProgressBar progressBar) {
        ApiService apiService = RetrofitClient.getApiService();
        Call<CharacterResponse> call = apiService.getCharacters(page);

        call.enqueue(new Callback<CharacterResponse>() {
            @Override
            public void onResponse(Call<CharacterResponse> call, Response<CharacterResponse> response) {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE); // Hide ProgressBar
                }
                if (response.isSuccessful() && response.body() != null) {
                    adapter.addCharacterList(response.body().getResults());
                    recyclerView.setVisibility(View.VISIBLE); // Show RecyclerView
                } else {
                    Toast.makeText(MainActivity.this, "Gagal mengambil data: " + response.message(), Toast.LENGTH_SHORT).show();
                }
                adapter.notifyItemChanged(adapter.getItemCount() - 1); // Refresh footer
            }

            @Override
            public void onFailure(Call<CharacterResponse> call, Throwable t) {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE); // Hide ProgressBar
                }
                Toast.makeText(MainActivity.this, "Terjadi kesalahan: " + t.getMessage(), Toast.LENGTH_LONG).show();
                adapter.notifyItemChanged(adapter.getItemCount() - 1); // Refresh footer
            }
        });
    }

}