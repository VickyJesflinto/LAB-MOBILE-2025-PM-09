package com.example.tp6_h071231092;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView imageView = findViewById(R.id.imageViewDetail);
        TextView textName = findViewById(R.id.textNameDetail);
        TextView textSpecies = findViewById(R.id.textSpeciesDetail);
        TextView textStatus = findViewById(R.id.textStatusDetail);
        TextView textGender = findViewById(R.id.textGenderDetail);
        LinearLayout errorLayout = findViewById(R.id.errorLayoutDetail);
        ImageButton btnRetry = findViewById(R.id.btnRetryDetail);
        LinearLayout cardViewLayout = findViewById(R.id.cardViewDetailLayout); // Wrap the CardView in a parent layout

        // Get data from intent
        String name = getIntent().getStringExtra("name");
        String species = getIntent().getStringExtra("species");
        String imageUrl = getIntent().getStringExtra("image");
        String status = getIntent().getStringExtra("status");
        String gender = getIntent().getStringExtra("gender");

        // Check if data is valid
        if (name == null || species == null || imageUrl == null || status == null || gender == null) {
            errorLayout.setVisibility(View.VISIBLE);
            cardViewLayout.setVisibility(View.GONE); // Hide CardView layout
            Toast.makeText(this, "Data karakter tidak lengkap", Toast.LENGTH_LONG).show();
            return;
        }

        // Check network availability
        if (NetworkUtil.isNetworkAvailable(this)) {
            errorLayout.setVisibility(View.GONE);
            cardViewLayout.setVisibility(View.VISIBLE); // Show CardView layout

            // Set data to views
            textName.setText(name);
            textSpecies.setText(species);
            textStatus.setText(status);
            textGender.setText(gender);
            Glide.with(this).load(imageUrl).into(imageView);
        } else {
            errorLayout.setVisibility(View.VISIBLE);
            cardViewLayout.setVisibility(View.GONE); // Hide CardView layout
        }

        // Retry button logic
        btnRetry.setOnClickListener(v -> {
            if (NetworkUtil.isNetworkAvailable(this)) {
                errorLayout.setVisibility(View.GONE);
                cardViewLayout.setVisibility(View.VISIBLE); // Show CardView layout

                // Set data to views
                textName.setText(name);
                textSpecies.setText(species);
                textStatus.setText(status);
                textGender.setText(gender);
                Glide.with(this).load(imageUrl).into(imageView);
            } else {
                Toast.makeText(this, "Tidak ada koneksi internet", Toast.LENGTH_LONG).show();
            }
        });
    }
}