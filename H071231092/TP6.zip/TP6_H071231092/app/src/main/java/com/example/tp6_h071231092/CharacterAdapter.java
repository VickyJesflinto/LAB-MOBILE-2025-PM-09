package com.example.tp6_h071231092;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CharacterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Character> characterList = new ArrayList<>();
    private static final int VIEW_TYPE_ITEM = 0;
    private static final int VIEW_TYPE_FOOTER = 1;

    public void addCharacterList(List<Character> newCharacters) {
        characterList.addAll(newCharacters);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        if (position == characterList.size()) {
            return VIEW_TYPE_FOOTER; // Footer view type
        }
        return VIEW_TYPE_ITEM; // Regular item view type
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_FOOTER) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_load_more, parent, false);
            return new FooterViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_character, parent, false);
            return new CharacterViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof FooterViewHolder) {
            FooterViewHolder footerHolder = (FooterViewHolder) holder;

            footerHolder.btnLoadMore.setVisibility(View.VISIBLE);
            footerHolder.btnLoadMore.setEnabled(true); // Ensure button is enabled

            footerHolder.btnLoadMore.setOnClickListener(v -> {
                footerHolder.btnLoadMore.setEnabled(false); // Disable button to prevent multiple clicks
                if (onLoadMoreListener != null) {
                    onLoadMoreListener.onLoadMore();
                }
            });
        } else if (holder instanceof CharacterViewHolder) {
            CharacterViewHolder itemHolder = (CharacterViewHolder) holder;
            Character character = characterList.get(position);
            itemHolder.textName.setText(character.getName());
            itemHolder.textSpecies.setText(character.getSpecies());

            // Load image using Glide
            Glide.with(holder.itemView.getContext())
                    .load(character.getImage())
                    .into(itemHolder.imageView);

            // Set OnClickListener
            itemHolder.itemView.setOnClickListener(v -> {
                Context context = holder.itemView.getContext();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("name", character.getName());
                intent.putExtra("species", character.getSpecies());
                intent.putExtra("image", character.getImage());
                intent.putExtra("status", character.getStatus());
                intent.putExtra("gender", character.getGender());
                context.startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        return characterList.size() + 1; // Add 1 for the footer
    }

    static class CharacterViewHolder extends RecyclerView.ViewHolder {
        TextView textName, textSpecies;
        ImageView imageView;

        public CharacterViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textName);
            textSpecies = itemView.findViewById(R.id.textSpecies);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }

    static class FooterViewHolder extends RecyclerView.ViewHolder {
        Button btnLoadMore;

        public FooterViewHolder(@NonNull View itemView) {
            super(itemView);
            btnLoadMore = itemView.findViewById(R.id.btnLoadMore);
        }
    }

    // Listener for load more
    private OnLoadMoreListener onLoadMoreListener;

    public void setOnLoadMoreListener(OnLoadMoreListener listener) {
        this.onLoadMoreListener = listener;
    }

    public interface OnLoadMoreListener {
        void onLoadMore();
    }


}