package com.example.tp6_h071231092;

import java.util.List;

public class CharacterResponse {
    private List<Character> results;

    public List<Character> getResults() {
        return results;
    }
}

